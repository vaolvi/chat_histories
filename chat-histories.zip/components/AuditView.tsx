'use client';

import React, { useEffect, useState } from 'react';
import { ArrowLeft, User, ExternalLink, Download, Eye } from 'lucide-react';
import { motion } from 'motion/react';

interface AuditViewProps {
  onBack: () => void;
  auditId: string;
  auditClient: string;
  startDate: string;
  endDate: string;
}

interface Message {
  type: 'client' | 'bot' | 'ia';
  content: string;
  date?: string;
}

interface AuditMetadata {
  person?: string;
  client?: string;
  phone?: string;
  perfil?: string;
}

export default function AuditView({ onBack, auditId, auditClient, startDate, endDate }: AuditViewProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [metadata, setMetadata] = useState<AuditMetadata>({});
  const [loading, setLoading] = useState(true);

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      
      return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
    } catch (e) {
      return dateStr;
    }
  };

  const handleDownload = () => {
    const text = messages.map(m => `${m.type.toUpperCase()} [${formatDate(m.date)}]: ${m.content}`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-${auditId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleGoToBotconversa = () => {
    const id = metadata.phone || auditId.split('-')[1] || auditId;
    window.open(`https://app.botconversa.com.br/157287/live-chat/all/${id}`, '_blank');
  };

  useEffect(() => {
    const controller = new AbortController();
    
    const fetchHistory = async () => {
      setLoading(true);
      try {
        const res = await fetch("https://n8n.apto.vc/webhook/chat-histories", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({ 
            id: auditId, 
            startDate: startDate,
            endDate: endDate,
            filtro: false })
        });
        
        const data = await res.json();
        
        // The new format is an array with one object containing an "html" key which is the array of messages
        const messagesArray = (Array.isArray(data) && data[0]?.html) ? data[0].html : (Array.isArray(data) ? data : []);
        
        if (Array.isArray(messagesArray) && messagesArray.length > 0) {
          // Extract metadata from the first message if available
          const first = messagesArray[0];
          setMetadata({
            person: first.person,
            client: first.client,
            phone: first.phone,
            perfil: first.perfil || (auditId.startsWith('brokers') ? 'brokers' : 'companies')
          });
          
          setMessages(messagesArray.map((m: any) => {
            let type: 'client' | 'bot' | 'ia' = 'client';
            if (m.type === 'ai') type = 'ia';
            else if (m.type === 'bot') type = 'bot';
            else if (m.type === 'human') type = 'client';
            
            let content = m.content || '';
            
            // Heuristic 1: If content is HTML, try to find labels (keeping as fallback)
            if (content.includes('<')) {
              const parser = new DOMParser();
              const doc = parser.parseFromString(content, 'text/html');
              const labelEl = doc.querySelector('strong, b, .label');
              if (labelEl) {
                const label = (labelEl.textContent || '').toLowerCase();
                if (label.includes('cliente')) type = 'client';
                else if (label.includes('ia')) type = 'ia';
                else if (label.includes('bot')) type = 'bot';
              }
              // Strip HTML for the final content
              content = doc.body.textContent || content;
            }
            
            // Heuristic 2: Check for text prefixes if type is still default or from content
            const lowerContent = content.toLowerCase();
            if (lowerContent.startsWith('ia:')) type = 'ia';
            else if (lowerContent.startsWith('bot:')) type = 'bot';
            else if (lowerContent.startsWith('cliente:')) type = 'client';
            
            // Clean content from prefixes
            const cleanContent = content.replace(/^(Cliente|Bot|IA):/i, '').trim();
            
            return {
              type,
              content: cleanContent,
              date: m.date
            };
          }));
        } else {
          setMessages([]);
        }
      } catch (err: any) {
        if (err.name === 'AbortError') return;
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
    return () => controller.abort();
  }, [auditId, startDate, endDate]);

  const tipo = metadata.perfil || (auditId.startsWith('brokers') ? 'brokers' : 'companies');

  return (
    <div className="flex h-screen bg-[#f8f9fb] overflow-hidden">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-85 bg-[#f1f4f7] h-full p-8 gap-8 border-r border-slate-200">
        <div className="flex flex-col gap-1">
          <h2 className="text-xl font-display font-black text-blue-900 uppercase tracking-tight">Audit Details</h2>
          <p className="text-[11px] font-bold uppercase tracking-widest text-on-surface-variant/60">Conversation Metadata</p>
        </div>

        <div className="bg-white rounded-3xl p-6 ambient-shadow border-t-4 border-primary flex flex-col gap-6">
          <div className="space-y-4">
            {metadata.person && (
              <div className="bg-[#f1f4f7] p-4 rounded-2xl">
                <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant/60 mb-1">Pessoa</p>
                <p className="text-sm font-bold text-on-surface">{metadata.person}</p>
              </div>
            )}
            <div className="bg-[#f1f4f7] p-4 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant/60 mb-1">Cliente</p>
              <p className="text-sm font-bold text-on-surface">{metadata.client || auditClient || 'N/A'}</p>
            </div>
            <div className="bg-[#f1f4f7] p-4 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant/60 mb-1">Perfil</p>
              <p className="text-sm font-bold text-on-surface">{tipo === 'brokers' ? 'Corretor' : 'Empresa'}</p>
            </div>
          </div>

          {metadata.phone && (
            <button 
              onClick={handleGoToBotconversa}
              className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-sm hover:bg-primary/90 transition-all active:scale-95 flex items-center justify-center gap-2 shadow-lg shadow-primary/20"
            >
              <ExternalLink className="w-4 h-4" />
              Ir para Botconversa
            </button>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="px-8 py-5 bg-white/80 backdrop-blur-md border-b border-slate-100 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-6">
            <button 
              onClick={onBack}
              className="flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-primary/5 text-primary font-bold transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Voltar</span>
            </button>
            <h1 className="text-xl font-display font-bold text-blue-900">Conversation Audit</h1>
          </div>
          <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all">
            <User className="w-6 h-6" />
          </button>
        </header>

        {/* Chat Area */}
        <main className="flex-1 overflow-hidden p-6 lg:p-10">
          <div className="max-w-4xl mx-auto h-full flex flex-col bg-[#f1f4f7]/50 rounded-[2rem] overflow-hidden border border-slate-200/50 shadow-sm">
            <div className="flex-1 overflow-y-auto p-8 lg:p-12 space-y-10 scrollbar-thin">
              {loading ? (
                <div className="flex items-center justify-center h-full text-on-surface-variant">
                  🔄 Carregando histórico...
                </div>
              ) : messages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-on-surface-variant">
                  ⚠️ Nenhum histórico encontrado.
                </div>
              ) : (
                <>
                  <div className="flex justify-center">
                    <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-on-surface-variant/60 bg-white/80 px-6 py-2 rounded-full shadow-sm">
                      Histórico da Sessão
                    </span>
                  </div>

                  {messages.map((msg, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: msg.type === 'client' ? -20 : 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`flex flex-col ${msg.type === 'client' ? 'items-start' : 'items-end'} max-w-[85%] lg:max-w-[70%] ${msg.type !== 'client' ? 'ml-auto' : ''}`}
                    >
                      <div className={`flex items-center gap-2 mb-2 ${msg.type === 'client' ? 'ml-2' : 'mr-2'}`}>
                        <span className={`text-[10px] font-bold uppercase tracking-wider ${msg.type === 'client' ? 'text-on-surface-variant' : 'text-primary'}`}>
                          {msg.type === 'client' ? 'Cliente' : msg.type === 'ia' ? 'IA' : 'Bot'}
                        </span>
                      </div>
                      <div className={`${msg.type === 'client' ? 'bg-white text-on-surface border border-slate-100' : 'hero-gradient text-white'} px-6 py-5 rounded-3xl ${msg.type === 'client' ? 'rounded-bl-sm' : 'rounded-br-sm'} ambient-shadow`}>
                        <p className="text-sm leading-relaxed font-medium whitespace-pre-wrap">{msg.content}</p>
                      </div>
                      {msg.date && (
                        <span className="text-[10px] text-on-surface-variant/60 mt-2 mx-2 font-bold">
                          {formatDate(msg.date)}
                        </span>
                      )}
                    </motion.div>
                  ))}
                </>
              )}
            </div>

            {/* Footer */}
            <div className="p-8 bg-white border-t border-slate-100">
              <div className="flex items-center justify-between text-on-surface-variant">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                    <Eye className="w-4 h-4 text-slate-400" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest opacity-60">Modo de Apenas Leitura (Arquivo Histórico)</span>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={handleDownload}
                    className="p-3 hover:bg-slate-50 rounded-xl transition-all text-slate-400 hover:text-primary"
                    title="Download Histórico"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
