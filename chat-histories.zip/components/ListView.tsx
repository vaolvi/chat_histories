'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Search, Eye, User, ChevronLeft, ChevronRight, Calendar as CalendarIcon, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';
import DatePicker, { registerLocale } from 'react-datepicker';
import { ptBR } from 'date-fns/locale/pt-BR';
import "react-datepicker/dist/react-datepicker.css";

registerLocale('pt-BR', ptBR);

interface ListViewProps {
  onSelectAudit: (id: string, client: string, startDate: string, endDate: string) => void;
}

interface AuditItem {
  session_id: string;
  client: string;
}

interface ListState {
  items: AuditItem[];
  startDate: string;
  endDate: string;
  tipo: string;
  idRef: string;
  currentPage: number;
  hasFetchedInitial: boolean;
  viewedIds: string[];
}

interface ListViewProps {
  onSelectAudit: (id: string, client: string, startDate: string, endDate: string) => void;
  listState: ListState;
  setListState: React.Dispatch<React.SetStateAction<ListState>>;
}

export default function ListView({ onSelectAudit, listState, setListState }: ListViewProps) {
  const [loading, setLoading] = useState(false);
  const itemsPerPage = 10;

  const { items, startDate, endDate, tipo, idRef, currentPage, hasFetchedInitial, viewedIds } = listState;

  const updateState = useCallback((updates: Partial<ListState>) => {
    setListState(prev => ({ ...prev, ...updates }));
  }, [setListState]);

  const fetchData = useCallback(async (type: string, id: string, start: string, end: string) => {
    setLoading(true);
    updateState({ currentPage: 1 });
    try {
      const sessionId = id ? `${type}-${id}` : "";
      const res = await fetch("https://n8n.apto.vc/webhook/chat-histories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          tipo: type, 
          id: sessionId, 
          startDate: start, 
          endDate: end, 
          filtro: true 
        })
      });
      const data = await res.json();
      updateState({ items: Array.isArray(data) ? data : [] });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [updateState]);

  useEffect(() => {
    // Only fetch if initial fetch hasn't happened yet
    if (!hasFetchedInitial) {
      const hoje = new Date();
      const ontem = new Date();
      ontem.setDate(hoje.getDate() - 1);
      
      const start = ontem.toISOString().split("T")[0];
      const end = hoje.toISOString().split("T")[0];
      
      updateState({ startDate: start, endDate: end, hasFetchedInitial: true });
      fetchData('', '', start, end);
    }
  }, [hasFetchedInitial, updateState, fetchData]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchData(tipo, idRef, startDate, endDate);
  };

  const totalPages = Math.ceil(items.length / itemsPerPage);
  const paginatedItems = items.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const parseDate = (dateStr: string) => {
    if (!dateStr) return null;
    const [year, month, day] = dateStr.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  const formatDateForState = (date: Date | null) => {
    if (!date) return "";
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="h-screen overflow-hidden flex flex-col bg-[#f8f9fb]">
      <header className="shrink-0 z-40 w-full px-8 py-4 bg-white/80 backdrop-blur-md border-b border-slate-100 flex justify-between items-center">
        <h2 className="text-2xl font-display font-bold text-primary">Conversation Audit</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-on-surface-variant bg-[#f1f4f7] px-4 py-2 rounded-full text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            System Active
          </div>
          <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all">
            <User className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden max-w-7xl mx-auto w-full px-8 py-6 flex flex-col gap-6">
        {/* Filters */}
        <form onSubmit={handleSearch} className="shrink-0 grid grid-cols-1 md:grid-cols-12 gap-4 items-end bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="md:col-span-12">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-on-surface-variant/60 mb-2">Search Filters</h3>
          </div>
          
          <div className="md:col-span-2 space-y-1.5">
            <label className="block text-[11px] font-bold text-on-surface-variant ml-1">Start Date</label>
            <div className="relative">
              <DatePicker
                selected={parseDate(startDate)}
                onChange={(date: Date | null) => updateState({ startDate: formatDateForState(date) })}
                dateFormat="dd/MM/yyyy"
                locale="pt-BR"
                placeholderText="Selecione"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-sm px-4 py-2.5 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all cursor-pointer hover:border-slate-300"
              />
              <CalendarIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="md:col-span-2 space-y-1.5">
            <label className="block text-[11px] font-bold text-on-surface-variant ml-1">End Date</label>
            <div className="relative">
              <DatePicker
                selected={parseDate(endDate)}
                onChange={(date: Date | null) => updateState({ endDate: formatDateForState(date) })}
                dateFormat="dd/MM/yyyy"
                locale="pt-BR"
                placeholderText="Selecione"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-sm px-4 py-2.5 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all cursor-pointer hover:border-slate-300"
              />
              <CalendarIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="md:col-span-3 space-y-1.5">
            <label className="block text-[11px] font-bold text-on-surface-variant ml-1">Profile</label>
            <div className="relative group">
              <select 
                value={tipo}
                onChange={(e) => updateState({ tipo: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-sm px-4 py-2.5 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all appearance-none cursor-pointer hover:border-slate-300"
              >
                <option value="">Select Profile Type</option>
                <option value="companies">Empresa</option>
                <option value="brokers">Corretor</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 group-hover:text-primary transition-colors">
                <ChevronDown className="w-4 h-4" />
              </div>
            </div>
          </div>

          <div className="md:col-span-3 space-y-1.5">
            <label className="block text-[11px] font-bold text-on-surface-variant ml-1">ID Reference</label>
            <input 
              type="text" 
              placeholder="Enter ID..." 
              value={idRef}
              onChange={(e) => updateState({ idRef: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl text-sm px-4 py-2.5 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all hover:border-slate-300" 
            />
          </div>

          <div className="md:col-span-2">
            <button type="submit" className="w-full h-[42px] bg-primary text-white rounded-xl font-bold text-sm shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all active:scale-95 flex items-center justify-center gap-2">
              <Search className="w-4 h-4" />
              Buscar
            </button>
          </div>
        </form>

        {/* Table Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1 min-h-0 bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col"
        >
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="min-w-full inline-block align-middle">
              <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr className="bg-slate-50 border-b border-slate-100">
                    <th className="px-8 py-4 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest bg-slate-50">Cliente</th>
                    <th className="px-8 py-4 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-center bg-slate-50">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {loading ? (
                    <tr>
                      <td colSpan={2} className="px-8 py-10 text-center text-on-surface-variant">
                        🔄 Carregando resultados...
                      </td>
                    </tr>
                  ) : paginatedItems.length === 0 ? (
                    <tr>
                      <td colSpan={2} className="px-8 py-10 text-center text-on-surface-variant">
                        ⚠️ Nenhum resultado encontrado.
                      </td>
                    </tr>
                  ) : (
                    paginatedItems.map((item, idx) => {
                      const isViewed = viewedIds.includes(item.session_id);
                      return (
                        <tr 
                          key={`${item.session_id}-${idx}`} 
                          className="hover:bg-slate-50/50 transition-colors group cursor-pointer" 
                          onClick={() => onSelectAudit(item.session_id, item.client, startDate, endDate)}
                        >
                          <td className="px-8 py-6">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold transition-all">
                                {item.client ? item.client.substring(0, 2).toUpperCase() : '??'}
                              </div>
                              <div>
                                <p className="text-sm font-bold text-on-surface">{item.client || 'N/A'}</p>
                                <p className="text-[11px] font-medium text-on-surface-variant">
                                  {item.session_id.startsWith('brokers') ? 'Corretor' : 'Empresa'}
                                </p>
                              </div>
                            </div>
                          </td>
                          <td className="px-8 py-6 text-center">
                            <div className="flex flex-col items-center gap-1">
                              <button className={`inline-flex items-center justify-center w-10 h-10 rounded-full transition-all ${isViewed ? 'text-emerald-500 bg-emerald-50' : 'hover:bg-primary/10 text-primary'}`}>
                                <Eye className="w-5 h-5" />
                              </button>
                              {isViewed && (
                                <span className="text-[11px] font-medium text-on-surface-variant">
                                  Visualizado
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          <div className="shrink-0 px-8 py-4 bg-slate-50/30 flex justify-between items-center border-t border-slate-100">
            <p className="text-[11px] font-medium text-on-surface-variant">
              Showing {paginatedItems.length} of {items.length} conversations
            </p>
            <div className="flex gap-2">
              <button 
                disabled={currentPage === 1 || loading}
                onClick={() => updateState({ currentPage: currentPage - 1 })}
                className="p-2 text-on-surface-variant hover:bg-white rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                // Simple pagination logic for showing a few pages
                let pageNum = i + 1;
                if (totalPages > 5 && currentPage > 3) {
                  pageNum = currentPage - 3 + i;
                  if (pageNum + 5 > totalPages) pageNum = totalPages - 4;
                }
                if (pageNum <= 0) pageNum = 1;
                if (pageNum > totalPages) return null;

                return (
                  <button 
                    key={pageNum}
                    onClick={() => updateState({ currentPage: pageNum })}
                    className={`w-8 h-8 flex items-center justify-center text-xs font-bold rounded-lg transition-all ${currentPage === pageNum ? 'bg-primary text-white shadow-sm' : 'text-on-surface-variant hover:bg-white'}`}
                  >
                    {pageNum}
                  </button>
                );
              })}

              <button 
                disabled={currentPage === totalPages || totalPages === 0 || loading}
                onClick={() => updateState({ currentPage: currentPage + 1 })}
                className="p-2 text-on-surface-variant hover:bg-white rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}
