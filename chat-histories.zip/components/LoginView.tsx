'use client';

import React, { useState } from 'react';
import { History, Lock, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginViewProps {
  onUnlock: () => void;
}

export default function LoginView({ onUnlock }: LoginViewProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;

    setLoading(true);
    setError('');
    try {
      const res = await fetch("https://n8n.apto.vc/webhook/chat-histories-access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      
      if (data && data.access === false) {
        setError("Senha incorreta. Tente novamente.");
      } else {
        onUnlock();
      }
    } catch (err) {
      console.error(err);
      setError("Erro ao validar senha. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#f8f9fb] bg-[radial-gradient(at_0%_0%,rgba(95,158,251,0.1)_0px,transparent_50%),radial-gradient(at_100%_100%,rgba(0,94,182,0.05)_0px,transparent_50%)]">
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12 text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="w-14 h-14 hero-gradient rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <History className="w-8 h-8" />
          </div>
        </div>
        <h1 className="font-display text-4xl font-extrabold tracking-tight text-on-surface">
          Chat Histories
        </h1>
      </motion.header>

      <motion.main 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="w-full max-w-[440px] relative"
      >
        <div className="absolute -top-px left-8 right-8 h-0.5 hero-gradient rounded-full z-10"></div>
        <div className="bg-white/85 backdrop-blur-3xl rounded-[2rem] ambient-shadow p-10 border border-white/20">
          <div className="mb-8">
            <h2 className="text-2xl font-display font-bold mb-2">Welcome Back</h2>
            <p className="text-on-surface-variant text-sm">Enter your password to access the archive</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-3">
              <div className="flex justify-between items-center px-1">
                <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant" htmlFor="password">
                  Secure Password
                </label>
                {error && (
                  <span className="text-[10px] font-bold text-rose-500 animate-pulse uppercase tracking-wider">
                    {error}
                  </span>
                )}
              </div>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none text-on-surface-variant group-focus-within:text-primary transition-colors">
                  <Lock className="w-5 h-5" />
                </div>
                <input 
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full h-16 bg-[#f1f4f7] text-on-surface placeholder:text-slate-400 border-none rounded-2xl pl-14 pr-5 focus:ring-2 focus:ring-primary/40 transition-all duration-200 outline-none ${error ? 'ring-2 ring-rose-500/20' : ''}`}
                  placeholder="••••••••••••"
                  required
                  disabled={loading}
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className={`w-full h-16 hero-gradient text-white font-display font-bold rounded-2xl shadow-lg shadow-primary/20 hover:brightness-110 active:scale-[0.98] transition-all duration-150 flex items-center justify-center gap-3 cursor-pointer ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              <span>{loading ? 'Validating...' : 'Unlock Archive'}</span>
              {!loading && <ArrowRight className="w-5 h-5" />}
            </button>
          </form>
        </div>
      </motion.main>
    </div>
  );
}
