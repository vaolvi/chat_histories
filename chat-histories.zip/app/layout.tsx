import type {Metadata} from 'next';
import { Inter, Manrope } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-display',
});

export const metadata: Metadata = {
  title: 'Luminous Archive',
  description: 'Sophisticated conversation audit system',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="pt-br" className={`${inter.variable} ${manrope.variable}`}>
      <body className="bg-[#f8f9fb] text-[#2d3337] font-sans antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
