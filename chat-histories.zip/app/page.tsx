'use client';

import React, { useState, useEffect } from 'react';
import LoginView from '@/components/LoginView';
import ListView from '@/components/ListView';
import AuditView from '@/components/AuditView';
import { motion, AnimatePresence } from 'motion/react';

type ViewState = 'login' | 'list' | 'audit';

interface AuditItem {
  session_id: string;
  client: string;
}

interface ListState {
  items: AuditItem[];
  startDate: string;
  endDate: string;
  tipo: string;
  idRef: string;
  currentPage: number;
  hasFetchedInitial: boolean;
  viewedIds: string[];
}

export default function Page() {
  const [view, setViewState] = useState<ViewState>('login');
  const [selectedAudit, setSelectedAudit] = useState<{ id: string; client: string; startDate: string; endDate: string }>({ 
    id: '', 
    client: '',
    startDate: '',
    endDate: ''
  });

  const [listState, setListState] = useState<ListState>({
    items: [],
    startDate: '',
    endDate: '',
    tipo: '',
    idRef: '',
    currentPage: 1,
    hasFetchedInitial: false,
    viewedIds: []
  });

  // Load viewedIds from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('viewed_audits');
    if (saved) {
      try {
        const ids = JSON.parse(saved);
        if (Array.isArray(ids)) {
          // eslint-disable-next-line react-hooks/set-state-in-effect
          setListState(prev => ({ ...prev, viewedIds: ids }));
        }
      } catch (e) {
        console.error('Error loading viewed audits:', e);
      }
    }
  }, []);

  // Save viewedIds to localStorage when it changes
  useEffect(() => {
    if (listState.viewedIds.length > 0) {
      localStorage.setItem('viewed_audits', JSON.stringify(listState.viewedIds));
    }
  }, [listState.viewedIds]);

  const handleUnlock = () => {
    setViewState('list');
  };

  const handleSelectAudit = (id: string, client: string, startDate: string, endDate: string) => {
    setSelectedAudit({ id, client, startDate, endDate });
    setListState(prev => ({ 
      ...prev, 
      viewedIds: prev.viewedIds.includes(id) ? prev.viewedIds : [...prev.viewedIds, id] 
    }));
    setViewState('audit');
  };

  const handleBackToList = () => {
    setViewState('list');
  };

  return (
    <main className="min-h-screen overflow-hidden">
      <AnimatePresence mode="wait">
        {view === 'login' && (
          <motion.div
            key="login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <LoginView onUnlock={handleUnlock} />
          </motion.div>
        )}

        {view === 'list' && (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ListView 
              onSelectAudit={handleSelectAudit} 
              listState={listState}
              setListState={setListState}
            />
          </motion.div>
        )}

        {view === 'audit' && (
          <motion.div
            key="audit"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AuditView 
              onBack={handleBackToList} 
              auditId={selectedAudit.id} 
              auditClient={selectedAudit.client}
              startDate={selectedAudit.startDate}
              endDate={selectedAudit.endDate}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
